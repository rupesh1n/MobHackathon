package com.activitytest.rupy.airasia;

import java.util.ArrayList;

/**
 * Created by Rupy on 2/13/2018.
 */

public class ModelClass {
    private String BookingStatus;
    private String PNR;
    private ArrayList<BookingContactsClass> BookingContacts;

    public void setBookingContacts(ArrayList<BookingContactsClass> bookingContacts) {
        BookingContacts = bookingContacts;
    }

    public class BookingContactsClass {
        private ArrayList<Name> Name;
    }
    public class Name {
        private String Title;
        private String FirstName;
        private String LastName;
    }

    public String getBookingStatus() {
        return BookingStatus;
    }

    public void setBookingStatus(String bookingStatus) {
        BookingStatus = bookingStatus;
    }

    public String getPNR() {
        return PNR;
    }

    public void setPNR(String PNR) {
        this.PNR = PNR;
    }

    public ArrayList<BookingContactsClass> getBookingContacts() {
        return BookingContacts;
    }


}
